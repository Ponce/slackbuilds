config() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "$(cat $OLD | md5sum)" = "$(cat $NEW | md5sum)" ]; then
    # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

# Keep same perms on rc.vboxadd-service.new:
if [ -e etc/rc.d/rc.vboxadd-service ]; then
  cp -a etc/rc.d/rc.vboxadd-service etc/rc.d/rc.vboxadd-service.new.incoming
  cat etc/rc.d/rc.vboxadd-service.new > etc/rc.d/rc.vboxadd-service.new.incoming
  mv etc/rc.d/rc.vboxadd-service.new.incoming etc/rc.d/rc.vboxadd-service.new
fi

config etc/rc.d/rc.vboxadd-service.new

# Create vboxadd user
if chroot . getent passwd vboxadd >/dev/null
then
  : vboxadd user already present
else
  USEROPT="-g 1 -u 215 -s /bin/sh -d /var/run/vboxadd"
  if chroot . useradd $USEROPT vboxadd 2>/dev/null
  then
    : vboxadd user successfully added
  else
    chroot . useradd vboxadd
  fi
fi

