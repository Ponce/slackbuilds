_onefetch() {
    local i cur prev opts cmd
    COMPREPLY=()
    if [[ "${BASH_VERSINFO[0]}" -ge 4 ]]; then
        cur="$2"
    else
        cur="${COMP_WORDS[COMP_CWORD]}"
    fi
    prev="$3"
    cmd=""
    opts=""

    for i in "${COMP_WORDS[@]:0:COMP_CWORD}"
    do
        case "${cmd},${i}" in
            ",$1")
                cmd="onefetch"
                ;;
            *)
                ;;
        esac
    done

    case "${cmd}" in
        onefetch)
            opts="-d -e -E -T -t -z -c -a -i -o -l -p -h -V --disabled-fields --no-title --number-of-authors --number-of-languages --number-of-file-churns --churn-pool-size --exclude --no-bots --no-merges --email --http-url --hide-token --include-hidden --type --text-colors --iso-time --number-separator --no-bold --ascii-input --ascii-colors --ascii-language --true-color --image --image-protocol --color-resolution --no-color-palette --no-art --nerd-fonts --output --generate --languages --package-managers --help --version"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 1 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --disabled-fields)
                    COMPREPLY=($(compgen -W "project description head pending version created languages dependencies authors last-change contributors url commits churn lines-of-code size license" -- "${cur}"))
                    return 0
                    ;;
                -d)
                    COMPREPLY=($(compgen -W "project description head pending version created languages dependencies authors last-change contributors url commits churn lines-of-code size license" -- "${cur}"))
                    return 0
                    ;;
                --number-of-authors)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --number-of-languages)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --number-of-file-churns)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --churn-pool-size)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --exclude)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -e)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --no-bots)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --type)
                    COMPREPLY=($(compgen -W "programming markup prose data" -- "${cur}"))
                    return 0
                    ;;
                -T)
                    COMPREPLY=($(compgen -W "programming markup prose data" -- "${cur}"))
                    return 0
                    ;;
                --text-colors)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -t)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --number-separator)
                    COMPREPLY=($(compgen -W "plain comma space underscore" -- "${cur}"))
                    return 0
                    ;;
                --ascii-input)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --ascii-colors)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -c)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --ascii-language)
                    COMPREPLY=($(compgen -W "nix scheme emacs-lisp powershell mojo vimscript raku abnf dart odin ruby sass python slint org crystal haskell fortran typst glsl zsh graphql jupyter-notebooks f# openscad typescript assembly batch processing javascript arduino ceylon agda xml ada modelica oz forth dockerfile xsl systemverilog zig sql idris r nim tsx java verilog makefile nushell elixir ats markdown svg text lua clojure jsonnet objective-c hlsl scala groovy cmake coq pascal tcl vhdl yaml protocol-buffers xaml just ocaml json c++ jsx llvm erlang html css lisp vue razor fortranmodern julia haxe swift webassembly c# autohotkey d coffeescript qml rust gdscript slang cuda holyc emojicode svelte wolfram shell fish perl bash renpy lean visualbasic abap racket kotlin elm c coldfusion gleam prolog go hcl solidity tex purescript vala toml php" -- "${cur}"))
                    return 0
                    ;;
                -a)
                    COMPREPLY=($(compgen -W "nix scheme emacs-lisp powershell mojo vimscript raku abnf dart odin ruby sass python slint org crystal haskell fortran typst glsl zsh graphql jupyter-notebooks f# openscad typescript assembly batch processing javascript arduino ceylon agda xml ada modelica oz forth dockerfile xsl systemverilog zig sql idris r nim tsx java verilog makefile nushell elixir ats markdown svg text lua clojure jsonnet objective-c hlsl scala groovy cmake coq pascal tcl vhdl yaml protocol-buffers xaml just ocaml json c++ jsx llvm erlang html css lisp vue razor fortranmodern julia haxe swift webassembly c# autohotkey d coffeescript qml rust gdscript slang cuda holyc emojicode svelte wolfram shell fish perl bash renpy lean visualbasic abap racket kotlin elm c coldfusion gleam prolog go hcl solidity tex purescript vala toml php" -- "${cur}"))
                    return 0
                    ;;
                --true-color)
                    COMPREPLY=($(compgen -W "auto never always" -- "${cur}"))
                    return 0
                    ;;
                --image)
                    local oldifs
                    if [ -n "${IFS+x}" ]; then
                        oldifs="$IFS"
                    fi
                    IFS=$'\n'
                    COMPREPLY=($(compgen -f "${cur}"))
                    if [ -n "${oldifs+x}" ]; then
                        IFS="$oldifs"
                    fi
                    if [[ "${BASH_VERSINFO[0]}" -ge 4 ]]; then
                        compopt -o filenames
                    fi
                    return 0
                    ;;
                -i)
                    local oldifs
                    if [ -n "${IFS+x}" ]; then
                        oldifs="$IFS"
                    fi
                    IFS=$'\n'
                    COMPREPLY=($(compgen -f "${cur}"))
                    if [ -n "${oldifs+x}" ]; then
                        IFS="$oldifs"
                    fi
                    if [[ "${BASH_VERSINFO[0]}" -ge 4 ]]; then
                        compopt -o filenames
                    fi
                    return 0
                    ;;
                --image-protocol)
                    COMPREPLY=($(compgen -W "kitty sixel iterm" -- "${cur}"))
                    return 0
                    ;;
                --color-resolution)
                    COMPREPLY=($(compgen -W "16 32 64 128 256" -- "${cur}"))
                    return 0
                    ;;
                --output)
                    COMPREPLY=($(compgen -W "json yaml" -- "${cur}"))
                    return 0
                    ;;
                -o)
                    COMPREPLY=($(compgen -W "json yaml" -- "${cur}"))
                    return 0
                    ;;
                --generate)
                    COMPREPLY=($(compgen -W "bash elvish fish powershell zsh" -- "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
    esac
}

if [[ "${BASH_VERSINFO[0]}" -eq 4 && "${BASH_VERSINFO[1]}" -ge 4 || "${BASH_VERSINFO[0]}" -gt 4 ]]; then
    complete -F _onefetch -o nosort -o bashdefault -o default onefetch
else
    complete -F _onefetch -o bashdefault -o default onefetch
fi
